
Instead Jtag Ver 0.40:

This program is  for FULL nagra emu with H2Deetoo Emulator version 3.3 and 4.0:
(And still preliminary)

As U know in Emu 3.3 There is support for Cabo, D+ and Polsat, each using its own eeprom image. You must upload all 3 images to the following addresses, using JTAG:

  0xC07F6000 <- D+ EE
  0xC07F8000 <- CABO EE
  0xC07FA000 <- POLSAT EE

This utility will help (I hope!) to upload EEprom image without Jtag, just through Serial cable (on COM1).
I successfully examined it on DSR9500 VIA CI and polsat.
Uploading each ROM files takes about 25 minuets!!!! It is because this program uses DSR9500 internal commands. by adding delay control anybody has ability to control upload speed.

This program was written by VB6, and of curse Runtimes are necessary.

Instruction:
------------

1-	Kill DSR from back for about 5 minutes and keep DSR stand by.
2-	Press Connect bottom.
3-	Select between (D+, Cabo & polsat) radio bottoms.
4-	Press " Open and Insert Rom File >>>" then select related ROM file to be uploaded.
5-	After about 25 minutes, if Any Error reported Press "Recover Inserted Rom File >>>". 			Continue Recovery until U receive NO_ERRORS.
6-	Press Disconnect Bottom.

*** IF DURING USING THIS PRGRAMM DSR HALTTED, DON�T WORRY !! (IT IS A COMMON PROBLEM) JUST KILL DSR FROM BACK AND REDO INSTRUCTION.

Remember that:
1- The files are stored in RAM only (so after power removal the RAM is empty again!)
2- Shorter delays causes More Errors and DSR Halts.( It is recommended not to change Delay )

History:
--------
Instead Jtag Ver 0.40:

	Freezing bug removed
	Delay subroutine improved
	All other Reported bugs by the time are removed

Instead Jtag Ver 0.36:

	Disconnecting bug removed 

Instead Jtag Ver 0.35:

	After disconnect Reboot STB (very very Important)

Instead Jtag Ver 0.3:

	Delay Control added

Instead Jtag Ver 0.2:

	Some minor changes in form refresh

Instead Jtag Ver 0.1:

	First release.

<<ALL RIGHTS OF THIS CODE (if any) BELONG TO ISFORUMS>>
 
msaeedz
March 25, 2004

