===============================================================================
jKeys Version 2.0.1 by Dave2

jKeys is a program primarily used to access memory on IRDs.  It works by utlizing processor diagnostic devices via the JTAG port.  This software has been used on STMicroelectronics STiXXXX (ST20 based core) and LSI SC2000 processors.

Basic
-----
- works on Windows 95/98/Me/NT/2K/XP
- auto detects STMicroelectronics ST20 base processors and LSI SC2000
  (ST micros STi5500, STi5505, STi5508, STi5510, STi5518, ST20-TP2, ST20-TP4, ST20-GP6) (LSI micro SC2000).
- auto detects most Echostar IRDs (2700, 2800, 3700, 3800, 3900, 4700, 4900, 501/5100, 301/3100, 6000)
- for IRDs detected, automatically read IRD number, Box Keys, Build Config, Model ID, Boot Strap and Software version
- works on several DTV IRDs (DRD420RE, DRD431RG, DRD220)
- for all IRDs known by jKeys, base memory flash configuration is provided
- allows flash reads for non-16 bit wide memory layouts
- reads memory and saves to file
- parallel port diagnostics

Advanced
--------
- Development Panel (STi based mostly)
	- check and adjust EMI configuration registers
	- trap read/write byte, word ,dword
	- DCU Peek/Poke
	- EJTAG DMA Read/Write (SC2000)
	- upload user's function, pass arguments, trigger function , read back values
- Passive Trap (STiXXXX)

- Flash Programming (STi and LSI)
	- auto detects flash memory (shows base, size, mfg/dev codes, manufacturer and part number)
	  (29F400BT, 29DL323T, 29F400BB, 29LV160DT/DB, M29F400T, M29W800AT, 28F320/J5/J3A/S3/S5, 28F160, 28F800B/B5-B)
	- user specified base address for manually detecting flash memory
	- blank check prior to write (STi only)
	- read/erase/program complete flash/sector

- EEPROM Programming
	- now reads/writes to I2C EEPROM via JTAG

===============================================================================
Release History
---------------
Version 2.0.1 (Build 008) (May 27, 2002)
 Added checksum calc for IRD#
 Added full notation naming for flash and EEPROM
 Added user selectable default directory for files (File | Preferences)

Version 2.0.0 (Build 007) (May 22, 2002)
 Added STi based 301/3100 IRD
 Added EEPROM routines for 501/5100
 Fixed EEPROM read/write on (LSI Version) DP301/3100, LSI main command routine not responding immediately after load causing false EEPROM read completion indication.
 Fixed DP301/3100 (LSI Version) IC22/IC23 base address reference.

Version 2.0.0 (Build 002) (May 13, 2002)
 Major re-work, many internals re-worked, you gotta try it!!

Version 1.3.3 (Build 106) (December 31,2001)
 Added support for ST M29F400T (Expanded instruction addresses to 4 octets)

Version 1.3.2 (Build 105) (December 21, 2001)
 Added STi5505, Corrected ST20-TP4 and STi5508 detection
 Added support for AM29DL323 flash support

Version 1.3.1 (Build 104) (October 21, 2001)
 Allowed Flash Detect/DCU Peek/Poke on Flash Tools page even if flash not detected

Version 1.3.1 (October 14, 2001)
 Added 28Fxxx flash support (RCA Model drd420re DTV)
 Automatically pulls IRD and Box Keys on start up
 Added passive trap for STiXXXX processors
 Added user definable flash base address and flash detect button in flash tools
 Added performance indicator option to indicate erase/detect/programming times 
 Added Get Flash ID in Flash Tools
 Added user definable base address in flash tools
 Flash Tools now additionally displays flash size, manufacturer and part number
 Added DCU Peek/Poke to Flash Tool
 Added EMI config register display/modify dialog accessible from Flash Tools
 
Version 1.2.2(a/b)
 Automatically detects STiXXXX and SC2000 processors.
 Added SC2000 EJTAG and DMA Read/Write.

Version 1.2.1
 Added 29x160 flash detection (2M flash) for programming.

Version 1.2.0
 Added Flash Tools for flash programming using IRD side code for fast writes (to 29040 flash currently).

Version 1.1.0
 Slight enhancements, dialog allowed DCU Poke/Peek, JTAG comm logging

Version 1.0.0 (August 2001)
 First version - read memory only, STi55xx processor, port diagnostics

===============================================================================
Contributions and Credits

Of course I can't take all the credit for everthing that jKeys does.  In creating the program I've had several people make suggestions and provide a great deal of assistance.  This includes some program segments, algorithm sequencing, interface communications, and of course beta testing.  I can't recall all of the people, but as many as I can are noted below:

blaknite, rerobs, *SatHackr, *Inssomniak, *satFTA, *dishwasher, *shellot, vankanma, Crispy, DishNightOwl, MageMinds, bula, TRoN, netsurge, manshank, Davez, Meister, Stibby, *tedgreen, *jandv, ds9luvr, rerobs, scanrite, and Dave2.

Original Version - well I can't recall everyone and as I try to I can't read the posts any further.

Anonymous - as well there were a few who sent me hard to find information or would give me some insight, and thanks to those.
