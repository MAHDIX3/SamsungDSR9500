Version 5.3_CW    11/5 2006

Cryptoworks Added.
Key-space Offset is changed from this version
so it can NOT be used with Older Ram-Bin/Firmware

---------------------------------------
Version 5.2   23/3 2006

Posibility to chose Export 
of Keys+Data between modechanging 
Nagra-5 <=====>   Nagra-17

A flag is set to Ram.bin when saving file 
(Offset 0X208 N-5  = "05"   N-17  = "11")
depending on if it is saved as N-5 or N-17.
This flag will be read when loading file
and editor will be set to correct mode for that file.

New option to get Nagra2 keys and other keys
downloaded from SoftCam.Key  URL
Put Your marker in Keytextbox for a certain Cas/Ident
Press "SHIFT" at keybord and click in textbox.

NAGRA 2
Doing the trick in Keyindex 00,
loads 16 Byte 00-Key to Index 08 and 09 polsat ; 0A and 0B  D+
Doing the trick in Keyindex 02,
loads 16 Byte 01-Key to Index 08 and 09 Polsat ; 0A and 0B  D+

For TPS AES Key, use method in Key 01 for Ident 007C00

...........................
Version 5.01  20/3 2006
KeyCounter fixed

Version 5.0   19/3 2006

What is new in this version:

Nb. of Nagra Idents and Irdeto Idents have been re-arranged
to work with new ToH/HoT 7.1 firmware and any new release
for Humax IRCI-5400

One Irdeto Ident has been removed to increase possible Nagra 
Idents in Ram from 5 to 17 

A new checkbox option is visible when Nagra or Irdeto is selected.
By ticking (or unticking) this checkbox, it is possible to switch 
between 2 different Ram configs (this feature is just made to make it 
compatible with older Rams for Sammy and older Humax firmwares)

_______________________________________________
If problems with Read/Write,
Install attached Microsoft Script Control
_______________________________________________

30 July 2004 Ver 4.3

Added "PIPE" function
Possible to hang on Sammytool in serial chain,

If Sammytool is running as  CS Client you can have
DSR9500 in between so it is possible to read/Write Keybuffer
even when SammyTool-CSClient is running.
(Need The latest SammyTool V 2.9 to do this)

Settings for "PIPE" to SammyTool is set
in Same textboxes as SYNCH "CLIENT-DETAILS"
Port and Host/IP are Used to connect to SammyTool > = 2.9

ECM's to Client passing through untouched to Sammytool
and DW returned from Sammytool will be transfered back to box.

[[SAMMY]] > comport> (DSR9500 EmuED) > Tcp/IP > (Sammytool 2.9)

26 July 2004 Ver 4.2

Option in Each User-account to Bypass
restricted SYNCH  KEYBUFFER_ONLY=1

This mean You can have set the KEYBUFFER_ONLY=1
in SYNCHSERVER, but Trusted USers can get the 
FULL SYNCH  anyway with Box at serverside.

Updates mostly for SYNCH Settings

When creating an Account and No pass is entered,
a random 10 x Chr's pass is auto generated.
Click on the "Details to Clipboard" button
and all info needed for the new account is in clipboard.

A few re-arranges in Menu's

Option for getting correct IP direct into the soft

(This is not really used, see it as info only,
Doubleclick on the Upper "SEVERSETTINGS" Textbox
and IP will be fetched from net)

This Info will only be used when pressing Button "Details to Clipboard"
Makes it easy to copy A special Account's details for sending to a User


Option for using Encrypted Keytransfer
Must be set on both sides for getting
transfered bytes to editor in correct format

Encryption Algo is Password dependent.
(Different Encryption for each User Account)
...........................................

25 July 2004 Ver 4.1

All Synch Settings can be set from Soft.

New Option for IP Security for Synch Option

[SHARE]
AUTOSET_IP=0  If set to 1, If A Users account have No IP as Filter when synching,
              Current IP Will be set as filter in Settings.ini
              (Means an Account can be set up without IP Check,
               First use of account, IP FIlter will be set for that account)


-------------------------------------------
24 July 2004 Ver 4.0

!!! From this Version, A "winsock" must be Correct registered. !!!!
!!! Because of NEW Synch Option with other Boxes !!!!

Added a Winsock Control
Now possible for Synch/Update Keybuffer between Boxes

Also 2 new Commandline parameter functions

SYNCH 
(This one does at once when starting soft
SYNCH keybuffer with configured Synch-server)

ASYNCH
(Same as above, but also Writes the Updated buffer
direct to Box, and then closes the soft down)
Theese two parameters require a valid Synch-Server is configured


New Synch functions must be configured in "Settings.ini"
Format as follows....
############################################################
To act as server,
Serversettings..

[SHARE]
LISTEN=1
PORT=1008
BUFFERONLY=1
AUTOBLOCKLIST=0
CHECKBLOCKLIST=1

... Explanations ...
LISTEN=1         ( Means soft is ready to work as server But You must press Button to start listening on port)
PORT=1           ( TCP/IP Port that server listen to)
BUFFERONLY=1     ( 1 means only available buffer loaded in server will be Shared to client
                   0 Means Each Allowed Request will Read keybuffer from conected Sammy before sharing it)
AUTOBLOCKLIST=0  ( 1 Means any Failed Login Request will put Remote IP in Blocklist )
CHECKBLOCKLIST=1 ( 1 Means IP is compared to Blocklist of Banned IP's, if exist in list, NO Access 
                     This one enabled will override Account/User profiles settings )
...........................

[SammyAddict]
PASS=gGtTyYuU
IP=
OK=1

... Explanations ...
[SammyAddict]     ( This is the name on this Allowed User to connect, every single user need his own section)
PASS=gGtTyYuU     ( USers Password to be allowed to connect )
IP=               ( Possibility to set required IP for above User/Pass, EX)192.168  will let any 192.168.*.* to connect, Nothing set means NO IP-Check)
OK=1              ( 1 means this Account/Profile is Enabled for the moment, 0 means User has no rights to connect )
��������������������������������������������������������������

To use as client , 
Client Settings

[SYNCHSERVER]
USER=SammyAddict
PASS=gGtTyYuU
IP=211.211.211.211
PORT=1008

... Explanations ...
USER=SammyAddict   ( Client USername for access to Synchserver )
PASS=gGtTyYuU      ( Client Password for access to Synchserver )
IP=211.211.211.211 ( IP/Host for Synchserver )
PORT=1008          ( Synch server Port to connect to  )

##################################################################

.....................................................
20 July 2004 Ver 3.9.2 Test

More Fixes with Softcam.key and Conax Handling
Takes care on both "C" and "X" as prefix for Conax Keyset
Conax also inside when exporting a SoftCam.Key
Double lines for Conax keys, with both Index's "C" and "X"
will be written to Exported SoftCam.Key
.....................................................
16 July 2004 Ver 3.9.1 Test
More commandline parameters available:

Drag and Drop a file on Exe or Shortcut
and it will be loaded in editor.

Added Drag and Drop for writing a Bin-file
Create a shortcut like this..
"E:\Sat\DSR9500\DSR 9500 EMU Ed391.exe" WR

Drag and drop a Key.bin on it and it will be Written to box

WR is the trigger for Autowrite it.

#######################################################################
.....................................................
15 July 2004 Ver 3.9

Added option for starting Editor and Automatically
update Keybuffer with help of a Command line Parameter.

Example :
"E:\Sat\DSR9500\DSR 9500 EMU Ed391.exe" AUTO

Create a Windows-shortcut to Soft,
rightclick and check Properties,
Put in Line in Format as above
(With !!!  YOUR PATH !!! of cause)
in TARGET- TExtbox
To use in Dos, Run Command You must change name to a shorter one.

It is the AUTO at the end of line that is the Trigger.


[Updated Internal File]
Added SECA Idents (0064-0065-0070-0071)
Added Keyset Indexes for Conax  (20-21)

New Default URL to SoftCam.key

Fixes when working with SoftCam.key's and Nagra RSA are present
now the soft dont Crash anymore

Conax Keysets are now taken care of (If in SoftCam.key)with Autoupdate of Box
and when Loaded SoftCam.key and Doubleclicking on Keyset in Id-List



___________________________________________
13 July 2004 Ver 3.8.1

Bypass of a strange Byte/Bit that sometimes
differ when Verifying.

___________________________________________
11 July 2004 Ver 3.8

Mostly Tuningstuff, and added options
during Test-Ver for some extra settings 
to get rid of Humax Problems.
(Still some left since Ver 3.7)

The Problem is Slow speed from Humax to 
deliver Keybuffer to Serial Port.

I dont want to make 2 different versions
so I have to make options so it will
fit different PC-Power and both Humax & Samsung.

THX Again guys for testing it out to
solve some Bugs :))

Hope even more can use this one without probs now.
A few Hummie guys tested it OK (Not OK before)

Another Bug when Reading of Keybuffer
and sometimes Crashed is hopefully gone

thx Mr Sammy ;-)  You know Who You are
Without You, 
this one would not be needed at all ;-)

_______________________________________________________
##################################################################
###########  TESTVERSIONS  #######################################

11 July 2004 Ver 3.7.4  (test)
Trying to solve  strange error that sometimes appear
when reading keybuffer...
Put in a CheckVariable to remember 
if IDlist is in focus or not
_______________________________________________________

11 July 2004 Ver 3.7.3  (test)
Added Readtimeout counter
"READTIMEOUT=8192" in inifile.
Default is "8192", if You get Timeout ERROR at 60 % reached Keybuffer
You have to increase "8192" 40 % which is "11469"
--------------------------------------------------------
Also a "ZEROCOUNTER" is added
(How many times in a row 0 bytes in COM-buffer is accepted
before stop the loop of catching bytes from comport)

ZEROCOUNTCHECK=0
Default set to 0 which bypasses Zerocount check
if set to f.ex 100
the Readprocess will stop if 
100 loop's in a row give ZERO bytes from comport.
Good to use this if using High "READTIMEOUT" and wrong COMPORT is choosen
cause readprocess will stop earlier when too many ZeroByte loops in a row.
---------------------------------------------------------
It is possible to set 3 diff stnd-config's 
depending on Your type of Computer
from " ? - Menu "

Fast
Default
Slow

[FAST]
ZEROCOUNTCHECK=300
READTIMEOUT=16384

[DEFAULT]
ZEROCOUNTCHECK=0
READTIMEOUT=8192

[SLOW]
ZEROCOUNTCHECK=20
READTIMEOUT=1000


Or to bypass theese settings, 
Just edit it manually in "Settings.ini"

Mostly Humax need to fiddle with theese settings.
Any of above settings "should" work with Samsung

##################################################################
##################################################################




----------------------------------------------
10 July 2004 Ver 3.7
Spending the whole day trying to 
solve the probs for Hummy Reading...
(A pain when no Hummy to test on  :(  )

Tremendous lot of help and testing from  
.... "..You know who You are :)  THX "

Hopefully some more Boxes now able to use this one.
At least my Helpful friend got his Hummy Up and Running Correct.

_______________________________________________
10 July 2004 Ver 3.6

Added Readspeed- control,
4096 is default value and this checks length
of Combuffer and reads whats in buffer loopwise
untill 4096 bytes is fetched.

Any other Value force Reading set amount of bytes each loop.
_______________________________________________
8 July 2004 Ver 3.5

!!  Totally New routines for Read and Write Keybuffer !!!!
 Hope it can sort some problems, but maybe make some new to.

_______________________________________________
-----------------------------------------------
8 July 2004 Ver 3.4
Added a simple Debug option
Comments will be put out to "Debug.txt" 
when Option marked in ?-Menu.
(Comments from "READ" and "WRITE" process)

Option unchecks itself after a "Debug-session"
and all text in Debug.txt will stay if 
running several Sessions in a row.

(Remember to Re-Check the option 
if wanting to run a 2'nd session)

This does NOT ! say what's wrong !!! ,
it is only a way to see how far in process
session is run before eventually a crash.
_____________________________________________
---------------------------------------------
4 July 2004 Ver 3.3
Tried to solve "Crash-Problems" with
Fawlty Keybuffer.
Fixed Export/Import of Via2 Format of Via-Keys

---------------------------------------------
4 July 2004 Ver 3.2
Option for Verifying after file is written
Can be set On/Off from Settings Menu "?"
------------------------------------------------

25 June 2004
M-Board for Help - Discussions - answers ....
Further discussions and Questions can be discussed here
http://eurocrypt.proboards32.com

23 May V2 Test
Option for Using 16 Byte Keys for Viaccess
Via2 NTV+ supported RAM files
can only be handled by the test Editor attached
Ver 3.1 and older can NOT handle it.

24 Apr 3.1.0
Comport can be changed from Menu "?" - "Settings" - "Comport"
FW-Check can be Disabled/Enabled From 
Menu "?" - "Settings" - "FW Check"
____________________________________________________________
13 Apr 3.0.0
Default settings can be set from Menu "?"
Label Is shown when FW Check is Disabled.
_____________________________________________________________
13 Apr 2.9.6-2.9.7
More adjustments and possibility
to Bypass FW check when Writing Buffer
(Now looks ok with Humax Emu  :)   )
Use this settings for Humax...
[SETTINGS]
FWCHECK=0
DELAY=10
FASTWRITE=1

Sammy can have this
[SETTINGS]
FWCHECK=1
DELAY=2
FASTWRITE=1
____________________________________________________________________
12 Apr 2004 Ver 2.9.3-2.9.5
Small Adjustments only...

____________________________________________________________________
12 Apr 2004  Ver 2.9.1

New Option in INI file
[SETTINGS]
FASTWRITE=1
================================
================================
==============================
Loops runs like this
==============================
FASTWRITE=1

16 Byte fast to box without delay
DELAY
16 Byte fast to box without delay

(Blocks of 16 byte at once and then DElay)

===============================

FASTWRITE=0
1 Byte to Box
DELAY
1 Byte to Box
DELAY
...
...
================================
================================
================================
My Sammy Like this Settings
Less then 2 Sec to write KEyfile:
[SETTINGS]
FASTWRITE=1
DELAY=1
================================
Humax EMU Should have this
[SETTINGS]
FASTWRITE=0
DELAY=25

================================


12 Apr 2004  Ver 2.9.1
Possibility to Use delay in Write routine
Default settings in Settings.ini In [SETTINGS]-Section
[SETTINGS]'
WRITEDELAY=10

This one could be changed to Higher value to write slower to box
_______________________________________________________________________
12 Apr 2004  Ver 2.9.0
Fix for Firmware check when Writing File
and changed a small Variable-declaration in Read routine

11 Apr  2004 ver 2.8.0.0
Speeded up Writing of Keybuffer.
Fixed problem with reading of
Keybuffer with errors inside.
(Sometimes errors inside RAmbuffer
when Editor reads it it can find 
f.ex Key on ViaID-Nr "FF", which is not present
and earlier Editor Crashed, 
now ignoring such errors...


18 Nov 2003 ver 2.6.0.0D
Rearanged SoftCam.Key Import Menu-section


17 Nov 2003    
Fixed 9 Idents for Ird/Beta now (Earlier only 8)


16 Nov 2003    Ver 2.5.0.0D
Option for writing an Empty Keybuffer (FF.....FF)
(Can be set to "00" in Settings.ini

Also a check of last used key inside a loaded Keybuffer
(Look in Menu-Item "?" )


________________________________________
10 Nov 2003   Ver 2.3.0.0
Fixed 9 Comport in list
________________________________________
Bugfixed 27 Okt 2003

Multiple Idents in Embedded File are gone now.

"First Freespace-pointer" fixed   <<<<  This one caused Problems !!


------------------------------------------
!!!!  IMPORTANT  READ 1�st !!!!

This Editor is only intended to be used
together with Samsung DSR 9500, 

Patched with H2Deetoo�s DSR 9500 Emu.

It needs MSInet.ocx correctly registered on Your System.


Msinet.ocx   is for "grabbing" [SoftCam.Key] from Web.

(Msinet.ocx may cause Your Firewall to scream...Dont Panic! )


###########################################################


Now over to some short and crappy instruction�s over
how to use this one......( Hope it�s not too confusing...)

// Euro


                   ---  Buttons    --- 
       
###########################################################

-----------------------------------------------------------
Read  - Using Win API to Read Keybuffer from Box into Editor
           
-----------------------------------------------------------
Write - Using Win API to to write File or Edited Keybuffer to Box

-----------------------------------------------------------
C - Copy, in ID-List selected ID/Provider+Keys
P - Paste Copied ID/Provider+Keys to in ID-List selected ID/Provider
X - Set in ID-List selected ID/Provider+Keys to ""

###########################################################




                    ---  Menus   ---

###########################################################
___________________________________________________________
Open File - Open a 4096 Byte large Keybuffer Bin-File
-----------------------------------------------------------
Save File - Save a 4096 Byte large Keybuffer Bin-File
            From edited Keybuffer loaded in Editor
___________________________________________________________
Load Internal Empty Bin - To start up a Keybuffer from "Scratch"
                          only some Ident�s as example inside.
___________________________________________________________
SoftCam - Key > Import Key >
 
Local - Open up a FileOpen browser where You can 
        "Point" to a [SoftCam.Key] on HardDrive
        Load it in editor for import of selected Keys
-----------------------------------------------------------
Web -  As above but Get the [SoftCam.Key] from Web-URL
-----------------------------------------------------------
Update Key-buff - As above, but also injects keys from
                 [SoftCam.Key] to Filebuffer,
                 But only to Idents allready existing in Filebuffer.
                 (No Providers/Ident�s will be Added )
-----------------------------------------------------------
�����������������������������������������������������������
   (BETA - BETA)     --All in one Menu-Click--  (BETA - BETA)

Autoupdate Box - 1: Reads Keybuffer from Box
                 2: Gets [SoftCam.Key] from WEB
                 3: Update Keys in FileBuffer
                 4: Writes Filebuffer back to Box

Sometimes this doesnt work on first CLICK , Try a 2'nd time if
Wrong FW MSG-Box pops up.

To have this enabled, You have to add a line in "Settings.ini"
under [SETTINGS] Section

AUTOUPDATE=1
�����������������������������������������������������������
___________________________________________________________

SoftCam - Key > 
Export Key - Export loaded Edited Buffer to [SoftCam.Key]

###########################################################




                   --- Other Functions ---

###########################################################

Use of [SoftCam.Key] functions manually :
-----------------------------------------------------------
Doubleclick on Left ID-List, to get 
corresponding Ident�s Keys from loaded [SoftCam.Key]
-----------------------------------------------------------
Singleclick on Right Id-List, sets Clicked ID+Keys to
selected ID/Provider-Position in LEft ID-List(Real Buffer)
-----------------------------------------------------------
There is a Hard Coded URL for [SoftCam.Key] inside,
but it can be bypassed if another URL is set  in [Settings.ini].

[SOFTCAMKEY]
URL=http://xamuh.modshack.co.uk/files/SoftCam.Key

(First use generates [Settings.ini])

-----------------------------------------------------------
When editing Keys, nothing will be changed in
filebuffer if not Length of Key is 16 digits
or 0 digits, 0 Digits removes Key-entry from buffer.

If You want to paste a key in this format  00 11 22 33 44 55 66 77
You can make sure it�s in Clipboard,
and simply Double-Click on the Key textbox You want it pasted into.


